#include <iostream>
#include "vegetableheader.h"
using namespace std;

int main(){
    Vegetables vegetable("Carrot", "Orange", "Root");
    vegetable.output();
}